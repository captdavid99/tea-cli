# tea-project-testnet

Hello, this repo is a form of my enthusiastic part in working on the Tea Testnet Project.
I'm still a beginner at things like this, but I want to keep learning.
Thank You.

DAVID
